#include <iostream>
using namespace std;

int main(void)
{
    printf("This is  a \"buggy\" program");
    return 0;
}