void printUnorderedPairs(int[] arrayA, int[] arrayB){
  for(int i = 0; i< arrayA.length; i++)
    for(int j = 0; j< 
}