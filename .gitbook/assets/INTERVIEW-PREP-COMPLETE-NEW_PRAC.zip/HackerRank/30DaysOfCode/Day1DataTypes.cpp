#include <iostream>
#include <iomanip>
#include <limits>

using namespace std;

int main() {
    int i = 4;
    double d = 4.0;
    string s = "HackerRank ";
    
//-----------------------------------------------------------------

    
   int lo;
   string lo2;
   double lo3;
    cin >> lo >> lo3 >> lo2;
    
    cout << lo + i << endl;
    cout <<  lo3 + d << endl;
    cout << s << lo2 << endl;
    
//---------------------------------------------------------------------
    return 0;
}
