#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

//--------------------------------------------------------------------


int main() 
{
    
    string input_string; 
    
    getline(cin, input_string); 
    
    cout << "Hello, World." << endl;
    
    cout << input_string << endl;


    return 0;
}
