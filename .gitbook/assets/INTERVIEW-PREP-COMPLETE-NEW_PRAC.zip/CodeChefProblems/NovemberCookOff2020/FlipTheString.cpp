#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    int T;

    cin >> T;

    while (T--)
    {
        string A, B;
        cin >> A >> B;

        if (A == B)
        {
            cout << 0 << endl;
            continue;
        }

    }
    return 0;
}