# cook your dish here
try:
    n = int(input())
    for i in range(n):
        x = int(input())
        if x < 10:
            print("What an obedient servant you are!")
        else:
            print("-1")
except:
    pass
