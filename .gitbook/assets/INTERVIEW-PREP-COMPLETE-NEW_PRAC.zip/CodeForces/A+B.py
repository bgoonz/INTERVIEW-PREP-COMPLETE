n = list(map(int, input().split()))
print(sum(n))
