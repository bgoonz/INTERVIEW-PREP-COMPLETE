#!/usr/bin/env pypy
n = int(input())
if n == 2:
    print("NO")
elif n % 2 == 0:
    print("YES")
else:
    print("NO")
