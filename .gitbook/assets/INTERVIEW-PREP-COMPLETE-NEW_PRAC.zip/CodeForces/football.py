n = str(input())
if "0000000" in n:
    print("YES")
elif "1111111" in n:
    print("YES")
else:
    print("NO")
