#include <math.h>
int Add(int x, int y)
{
    return log10(pow(10, x) * pow(10, y));
}