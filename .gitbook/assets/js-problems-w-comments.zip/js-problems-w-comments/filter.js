// Return an iterable object that filters the specified iterable,
// iterating only those elements for which the predicate returns true
function filter(iterable, predicate) {
  let iterator = iterable[Symbol.iterator]();
  return {
    // This object is both iterator and iterable
    [Symbol.iterator]() {
      return this;
    },
    next() {
      for (;;) {
        let v = iterator.next();
        if (v.done || predicate(v.value)) {
          return v;
        }
      }
    },
  };
}

// Filter a range so we're left with only even numbers
[...filter(new Range(1, 10), (x) => x % 2 === 0)]; // => [2,4,6,8,10]
